package com.example.programming1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ListActivity extends AppCompatActivity {
//    Button customer1;
//    Button customer2;
//    Button customer3;
//    Button customer4;
//    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
//        customer1 = findViewById(R.id.customer1);
//        customer1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                intent = new Intent(ListActivity.this,CustomerInfoActivity.class);
//                startActivity(intent);
//            }
//        });
//        customer2 = findViewById(R.id.customer2);
//        customer2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                intent = new Intent(ListActivity.this,CustomerInfoActivity.class);
//                startActivity(intent);
//            }
//        });
//        customer3 = findViewById(R.id.customer3);
//        customer3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                intent = new Intent(ListActivity.this,CustomerInfoActivity.class);
//                startActivity(intent);
//            }
//        });
//        customer4 = findViewById(R.id.customer4);
//        customer4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                intent = new Intent(ListActivity.this,CustomerInfoActivity.class);
//                startActivity(intent);
//            }
//        });


    }
}
